#!/usr/bin/env python3
"""Mini calendar — a small local server that talks to Google Calendar and Zoom.

Why it exists: the Google Calendar web app costs several hundred megabytes in its
own browser instance for what is, in daily use, a month grid with a handful of
actions. This keeps the month view, creating, editing, dragging events and Zoom
links, and drops everything else.

Only the standard library is used, so there is nothing to install.

Endpoints (all local, bound to 127.0.0.1):
    GET  /                       the page
    GET  /api/state              whether Google and Zoom are connected
    GET  /api/events?from&to     events in the range
    POST /api/events             create   {summary, start, end, zoom: bool, description}
    PATCH/api/events/<id>        change   {summary?, start?, end?, description?}
    DELETE /api/events/<id>      delete
    GET  /auth/google            starts the Google sign-in, returns the URL to open
    GET  /oauth2callback         the redirect target of that sign-in
"""
import http.server
import json
import os
import socketserver
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

HOST, PORT = "127.0.0.1", 8412
BASE = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.expanduser("~/.config/mini-calendar")
CREDENTIALS = os.path.join(CONFIG_DIR, "credentials.json")   # what you paste in from Google/Zoom
TOKENS = os.path.join(CONFIG_DIR, "tokens.json")             # what this app stores afterwards

GOOGLE_AUTH = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN = "https://oauth2.googleapis.com/token"
GOOGLE_API = "https://www.googleapis.com/calendar/v3"
SCOPE = "https://www.googleapis.com/auth/calendar.events"
REDIRECT = f"http://{HOST}:{PORT}/oauth2callback"

ZOOM_TOKEN = "https://zoom.us/oauth/token"
ZOOM_API = "https://api.zoom.us/v2"

_lock = threading.Lock()


def local_timezone():
    """IANA name of this machine's timezone — Google and Zoom both want it by name."""
    try:
        return os.path.realpath("/etc/localtime").split("zoneinfo/", 1)[1]
    except IndexError:
        return "UTC"


TZ = local_timezone()


# --------------------------------------------------------------------------- storage
def read_json(path, default=None):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default if default is not None else {}


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def credentials():
    return read_json(CREDENTIALS, {})


def tokens():
    return read_json(TOKENS, {})


# --------------------------------------------------------------------------- http helper
def request(url, method="GET", data=None, headers=None, form=False):
    headers = dict(headers or {})
    body = None
    if data is not None:
        if form:
            body = urllib.parse.urlencode(data).encode()
            headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
        else:
            body = json.dumps(data).encode()
            headers.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            text = r.read().decode()
            return json.loads(text) if text else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode()[:400]
        raise RuntimeError(f"{e.code} {e.reason}: {detail}") from None


# --------------------------------------------------------------------------- google
def google_access_token():
    with _lock:
        store = tokens()
        google = store.get("google", {})
        if google.get("access_token") and google.get("expires_at", 0) > time.time() + 60:
            return google["access_token"]
        refresh = google.get("refresh_token")
        if not refresh:
            return None
        creds = credentials().get("google", {})
        fresh = request(GOOGLE_TOKEN, "POST", {
            "client_id": creds.get("client_id", ""),
            "client_secret": creds.get("client_secret", ""),
            "refresh_token": refresh,
            "grant_type": "refresh_token",
        }, form=True)
        google.update(access_token=fresh["access_token"],
                      expires_at=time.time() + fresh.get("expires_in", 3600))
        store["google"] = google
        write_json(TOKENS, store)
        return google["access_token"]


def google(path, method="GET", data=None, params=None):
    token = google_access_token()
    if not token:
        raise RuntimeError("Google не подключён")
    url = f"{GOOGLE_API}{path}"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    return request(url, method, data, {"Authorization": f"Bearer {token}"})


# --------------------------------------------------------------------------- zoom
def zoom_access_token():
    creds = credentials().get("zoom", {})
    if not creds.get("client_id"):
        return None
    store = tokens()
    cached = store.get("zoom", {})
    if cached.get("access_token") and cached.get("expires_at", 0) > time.time() + 60:
        return cached["access_token"]
    import base64
    basic = base64.b64encode(f"{creds['client_id']}:{creds['client_secret']}".encode()).decode()
    fresh = request(ZOOM_TOKEN, "POST",
                    {"grant_type": "account_credentials", "account_id": creds["account_id"]},
                    {"Authorization": f"Basic {basic}"}, form=True)
    store["zoom"] = {"access_token": fresh["access_token"],
                     "expires_at": time.time() + fresh.get("expires_in", 3600)}
    write_json(TOKENS, store)
    return store["zoom"]["access_token"]


def zoom_create(summary, start_iso, minutes):
    token = zoom_access_token()
    if not token:
        return None
    meeting = request(f"{ZOOM_API}/users/me/meetings", "POST", {
        "topic": summary or "Встреча",
        "type": 2,
        "start_time": start_iso,
        "timezone": TZ,
        "duration": minutes,
        "settings": {"join_before_host": True, "waiting_room": False},
    }, {"Authorization": f"Bearer {token}"})
    return {"join_url": meeting.get("join_url"), "id": meeting.get("id")}


def zoom_delete(meeting_id):
    """Remove the Zoom meeting that belonged to a deleted event, so the account
    does not fill up with meetings nobody will ever join."""
    token = zoom_access_token()
    if not token or not meeting_id:
        return
    request(f"{ZOOM_API}/meetings/{meeting_id}", "DELETE", None,
            {"Authorization": f"Bearer {token}"})


def zoom_move(meeting_id, start_iso, minutes):
    token = zoom_access_token()
    if not token or not meeting_id:
        return
    request(f"{ZOOM_API}/meetings/{meeting_id}", "PATCH",
            {"start_time": start_iso, "timezone": TZ, "duration": minutes},
            {"Authorization": f"Bearer {token}"})


# --------------------------------------------------------------------------- server
class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=os.path.join(BASE, "static"), **kw)

    def log_message(self, *args):        # quiet
        pass

    # ---- helpers
    def reply(self, data, code=200):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def payload(self):
        length = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(length) or b"{}")

    def guard(self, fn):
        try:
            fn()
        except RuntimeError as exc:
            self.reply({"error": str(exc)}, 400)
        except Exception as exc:                       # noqa: BLE001 - surfaced in the UI
            self.reply({"error": f"{type(exc).__name__}: {exc}"}, 500)

    # ---- routes
    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(url.query)

        if url.path == "/api/state":
            creds = credentials()
            return self.reply({
                "google": bool(tokens().get("google", {}).get("refresh_token")),
                "google_configured": bool(creds.get("google", {}).get("client_id")),
                "zoom": bool(creds.get("zoom", {}).get("client_id")),
            })

        if url.path == "/api/events":
            return self.guard(lambda: self.reply(self.list_events(query)))

        if url.path == "/auth/google":
            creds = credentials().get("google", {})
            if not creds.get("client_id"):
                return self.reply({"error": "Сначала впишите client_id в ~/.config/mini-calendar/credentials.json"}, 400)
            params = urllib.parse.urlencode({
                "client_id": creds["client_id"], "redirect_uri": REDIRECT,
                "response_type": "code", "scope": SCOPE,
                "access_type": "offline", "prompt": "consent",
            })
            return self.reply({"url": f"{GOOGLE_AUTH}?{params}"})

        if url.path == "/oauth2callback":
            code = query.get("code", [""])[0]
            try:
                creds = credentials().get("google", {})
                fresh = request(GOOGLE_TOKEN, "POST", {
                    "code": code, "client_id": creds["client_id"],
                    "client_secret": creds["client_secret"],
                    "redirect_uri": REDIRECT, "grant_type": "authorization_code",
                }, form=True)
                store = tokens()
                store["google"] = {
                    "refresh_token": fresh["refresh_token"],
                    "access_token": fresh["access_token"],
                    "expires_at": time.time() + fresh.get("expires_in", 3600),
                }
                write_json(TOKENS, store)
                message = "Готово, календарь подключён. Можно закрыть эту вкладку."
            except Exception as exc:                   # noqa: BLE001
                message = f"Не получилось: {exc}"
            body = f"<!doctype html><meta charset=utf-8><body style='background:#0a0e11;color:#dfe8ee;font:16px Inter,sans-serif;padding:40px'>{message}</body>".encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            return self.wfile.write(body)

        return super().do_GET()

    def do_POST(self):
        if self.path == "/api/events":
            return self.guard(lambda: self.reply(self.create_event(self.payload())))
        self.reply({"error": "not found"}, 404)

    def do_PATCH(self):
        if self.path.startswith("/api/events/"):
            event_id = urllib.parse.unquote(self.path.rsplit("/", 1)[1])
            return self.guard(lambda: self.reply(self.update_event(event_id, self.payload())))
        self.reply({"error": "not found"}, 404)

    def do_DELETE(self):
        if self.path.startswith("/api/events/"):
            event_id = urllib.parse.unquote(self.path.rsplit("/", 1)[1])
            return self.guard(lambda: self.reply(self.delete_event(event_id)))
        self.reply({"error": "not found"}, 404)

    # ---- calendar operations
    def delete_event(self, event_id):
        meeting_id = None
        try:
            existing = google(f"/calendars/primary/events/{event_id}")
            meeting_id = (existing.get("extendedProperties", {}).get("private", {}) or {}).get("zoomMeetingId")
        except RuntimeError:
            pass
        google(f"/calendars/primary/events/{event_id}", "DELETE")
        if meeting_id:
            try:
                zoom_delete(meeting_id)
            except Exception:                          # noqa: BLE001 - the event is already gone
                pass
        return {"ok": True}

    def list_events(self, query):
        items = google("/calendars/primary/events", params={
            "timeMin": query.get("from", [""])[0],
            "timeMax": query.get("to", [""])[0],
            "singleEvents": "true", "orderBy": "startTime", "maxResults": "250",
        }).get("items", [])
        return [{
            "id": e["id"],
            "summary": e.get("summary", "(без названия)"),
            "start": e["start"].get("dateTime") or e["start"].get("date"),
            "end": e["end"].get("dateTime") or e["end"].get("date"),
            "allDay": "date" in e["start"],
            "description": e.get("description", ""),
            "location": e.get("location", ""),
            "zoom": "zoom.us" in (e.get("location", "") + e.get("description", "")),
        } for e in items]

    def create_event(self, data):
        body = {
            "summary": data.get("summary") or "Без названия",
            "start": {"dateTime": data["start"], "timeZone": TZ},
            "end": {"dateTime": data["end"], "timeZone": TZ},
            "description": data.get("description", ""),
        }
        if data.get("zoom"):
            minutes = max(15, int((_parse(data["end"]) - _parse(data["start"])) / 60))
            meeting = zoom_create(body["summary"], data["start"], minutes)
            if meeting:
                body["location"] = meeting["join_url"]
                body["description"] = (body["description"] + "\n\n" + meeting["join_url"]).strip()
                body["extendedProperties"] = {"private": {"zoomMeetingId": str(meeting["id"])}}
        return google("/calendars/primary/events", "POST", body)

    def update_event(self, event_id, data):
        body = {}
        if "summary" in data:
            body["summary"] = data["summary"]
        if "description" in data:
            body["description"] = data["description"]
        if "start" in data:
            body["start"] = {"dateTime": data["start"], "timeZone": TZ}
            body["end"] = {"dateTime": data["end"], "timeZone": TZ}
        updated = google(f"/calendars/primary/events/{event_id}", "PATCH", body)
        # keep the Zoom meeting in step with the event it belongs to
        meeting_id = (updated.get("extendedProperties", {}).get("private", {}) or {}).get("zoomMeetingId")
        if meeting_id and "start" in data:
            minutes = max(15, int((_parse(data["end"]) - _parse(data["start"])) / 60))
            try:
                zoom_move(meeting_id, data["start"], minutes)
            except Exception:                          # noqa: BLE001 - the event itself moved fine
                pass
        return updated


def _parse(iso):
    from datetime import datetime
    return datetime.fromisoformat(iso).timestamp()


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    os.makedirs(CONFIG_DIR, exist_ok=True)
    if not os.path.exists(CREDENTIALS):
        write_json(CREDENTIALS, {
            "google": {"client_id": "", "client_secret": ""},
            "zoom": {"account_id": "", "client_id": "", "client_secret": ""},
        })
    with Server((HOST, PORT), Handler) as httpd:
        httpd.serve_forever()


if __name__ == "__main__":
    main()
