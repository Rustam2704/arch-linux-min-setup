// Mini calendar — month view, create / edit / drag, and a Zoom link when asked.
'use strict';

const grid = document.getElementById('grid');
const titleEl = document.getElementById('title');
const statusEl = document.getElementById('status');
const connectBtn = document.getElementById('connect');
const dialog = document.getElementById('editor');
const form = document.getElementById('form');
const errorEl = document.getElementById('error');
const deleteBtn = document.getElementById('delete');

const MONTHS = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь',
                'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'];

let cursor = new Date();          // any day inside the month being shown
let events = [];
let editing = null;               // event being edited, or null when creating

const pad = n => String(n).padStart(2, '0');
const key = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const localIso = d => `${key(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}:00`;

function monthRange(date) {
    const first = new Date(date.getFullYear(), date.getMonth(), 1);
    const start = new Date(first);
    start.setDate(first.getDate() - ((first.getDay() + 6) % 7));      // grid starts on Monday
    const end = new Date(start);
    end.setDate(start.getDate() + 42);
    return [start, end];
}

async function api(path, options) {
    const res = await fetch(path, options);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || res.statusText);
    return data;
}

async function refreshState() {
    const state = await api('/api/state');
    connectBtn.hidden = state.google;
    if (!state.google_configured) {
        statusEl.innerHTML = 'нужен ключ Google — см. <b>ИНСТРУКЦИЯ.md</b>';
    } else if (!state.google) {
        statusEl.textContent = 'календарь не подключён';
    } else {
        statusEl.innerHTML = state.zoom ? 'Google · <b>Zoom</b>' : 'Google';
    }
    return state;
}

async function load() {
    const [start, end] = monthRange(cursor);
    titleEl.textContent = `${MONTHS[cursor.getMonth()]} ${cursor.getFullYear()}`;
    try {
        events = await api(`/api/events?from=${encodeURIComponent(start.toISOString())}&to=${encodeURIComponent(end.toISOString())}`);
    } catch (err) {
        events = [];
        statusEl.textContent = err.message;
    }
    draw();
}

function draw() {
    const [start] = monthRange(cursor);
    const today = key(new Date());
    const byDay = new Map();
    for (const e of events) {
        const k = e.start.slice(0, 10);
        if (!byDay.has(k)) byDay.set(k, []);
        byDay.get(k).push(e);
    }

    grid.replaceChildren();
    for (let i = 0; i < 42; i++) {
        const date = new Date(start);
        date.setDate(start.getDate() + i);
        const cell = document.createElement('div');
        cell.className = 'day';
        if (date.getMonth() !== cursor.getMonth()) cell.classList.add('other');
        if (key(date) === today) cell.classList.add('today');
        cell.dataset.date = key(date);

        const num = document.createElement('div');
        num.className = 'num';
        num.textContent = date.getDate();
        cell.appendChild(num);

        for (const e of byDay.get(key(date)) || []) {
            const chip = document.createElement('div');
            chip.className = 'event' + (e.zoom ? ' zoom' : '');
            chip.draggable = true;
            chip.dataset.id = e.id;
            const time = e.allDay ? '' : `<span class="time">${e.start.slice(11, 16)}</span>`;
            chip.innerHTML = time + escapeHtml(e.summary);
            chip.title = (e.allDay ? '' : e.start.slice(11, 16) + ' — ') + e.summary + (e.zoom ? '\nZoom' : '');
            chip.addEventListener('click', ev => { ev.stopPropagation(); openEditor(e); });
            chip.addEventListener('dragstart', ev => ev.dataTransfer.setData('text/plain', e.id));
            cell.appendChild(chip);
        }

        cell.addEventListener('click', () => openCreator(date));
        cell.addEventListener('dragover', ev => { ev.preventDefault(); cell.classList.add('drop'); });
        cell.addEventListener('dragleave', () => cell.classList.remove('drop'));
        cell.addEventListener('drop', ev => {
            ev.preventDefault();
            cell.classList.remove('drop');
            moveEvent(ev.dataTransfer.getData('text/plain'), date);
        });
        grid.appendChild(cell);
    }
}

function escapeHtml(s) {
    return s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

async function moveEvent(id, date) {
    const event = events.find(e => e.id === id);
    if (!event || event.allDay) return;
    const from = new Date(event.start), to = new Date(event.end);
    const length = to - from;
    const start = new Date(date);
    start.setHours(from.getHours(), from.getMinutes(), 0, 0);
    const end = new Date(start.getTime() + length);
    try {
        await api(`/api/events/${encodeURIComponent(id)}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ start: localIso(start), end: localIso(end) }),
        });
    } catch (err) {
        statusEl.textContent = err.message;
    }
    load();
}

function openCreator(date) {
    editing = null;
    const start = new Date(date);
    start.setHours(10, 0, 0, 0);
    const end = new Date(start.getTime() + 60 * 60 * 1000);
    form.summary.value = '';
    form.description.value = '';
    form.start.value = localIso(start).slice(0, 16);
    form.end.value = localIso(end).slice(0, 16);
    form.zoom.checked = false;
    form.zoom.parentElement.hidden = false;
    deleteBtn.hidden = true;
    errorEl.textContent = '';
    dialog.showModal();
    form.summary.focus();
}

function openEditor(event) {
    editing = event;
    form.summary.value = event.summary;
    form.description.value = event.description || '';
    form.start.value = (event.start || '').slice(0, 16);
    form.end.value = (event.end || '').slice(0, 16);
    form.zoom.checked = !!event.zoom;
    form.zoom.parentElement.hidden = true;        // an existing meeting keeps its link
    deleteBtn.hidden = false;
    errorEl.textContent = '';
    dialog.showModal();
    form.summary.focus();
}

dialog.addEventListener('close', async () => {
    const action = dialog.returnValue;
    if (action === 'cancel' || action === '') return;
    try {
        if (action === 'delete' && editing) {
            await api(`/api/events/${encodeURIComponent(editing.id)}`, { method: 'DELETE' });
        } else if (editing) {
            await api(`/api/events/${encodeURIComponent(editing.id)}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    summary: form.summary.value,
                    description: form.description.value,
                    start: form.start.value + ':00',
                    end: form.end.value + ':00',
                }),
            });
        } else {
            await api('/api/events', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    summary: form.summary.value,
                    description: form.description.value,
                    start: form.start.value + ':00',
                    end: form.end.value + ':00',
                    zoom: form.zoom.checked,
                }),
            });
        }
    } catch (err) {
        statusEl.textContent = err.message;
    }
    load();
});

connectBtn.addEventListener('click', async () => {
    try {
        const { url } = await api('/auth/google');
        window.open(url, '_blank');
    } catch (err) {
        statusEl.textContent = err.message;
    }
});

document.getElementById('prev').addEventListener('click', () => { cursor.setMonth(cursor.getMonth() - 1); load(); });
document.getElementById('next').addEventListener('click', () => { cursor.setMonth(cursor.getMonth() + 1); load(); });
document.getElementById('today').addEventListener('click', () => { cursor = new Date(); load(); });
document.addEventListener('keydown', ev => {
    if (dialog.open) return;
    if (ev.key === 'ArrowLeft') { cursor.setMonth(cursor.getMonth() - 1); load(); }
    if (ev.key === 'ArrowRight') { cursor.setMonth(cursor.getMonth() + 1); load(); }
    if (ev.key.toLowerCase() === 't') { cursor = new Date(); load(); }
});

refreshState().then(load);
setInterval(load, 5 * 60 * 1000);      // quietly stay in step with the server
